# CRUD PHP/MYSQL


## Configurando o Banco de Dados


Importe o arquivo agenda.sql para seu SGBD, depois coloque suas configurações de acesso ao banco de dados (login e senha) no arquivo
agenda\core\Database\DatabaseConnection.php


## Rodando a aplicação


Execute o comando abaixo na pasta do projeto para iniciar o servidor:

```sh
$ php -S localhost:8000
```




### Se houver algum 

Executar o comando do composer na pasta do projeto:

```sh
$ composer update
```
